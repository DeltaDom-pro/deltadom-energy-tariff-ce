## 0.1.0
- Initial Community Edition release
- Current price sensor (Base / HP-HC / Tempo manual / EV 3 windows / Dynamic placeholder)
- HC/HSC binary sensors
- Optional EUR/h cost rate sensor
- Blueprint helper: external Tempo day type → input_select
